# Robin Winters - Applied AI and forward-deployed role interests: public work-sample pack

Dated October 4, 2026. This is a self-authored selection of existing public work and professional evidence, assembled with editorial and coding-assistant support. It is not an independent assessment, a new credential or an employment application.

## Review path

1. Read role-resume.txt or the editable role-resume.docx.
2. Read professional-record.json for supported facts and unresolved details.
3. Review the included project accounts and focused review-guide.md.
4. Follow original evidence URLs and use MANIFEST.json to verify the included source snapshots.

Robin built the TORos prototype for Yukon Systems, as confirmed in the approved professional record. Its model-agnostic, multimodal deliberation design is discussed in the company article linked below. That company article does not establish sole authorship, collaborator credits, customer deployment or measured performance. The writing describes architecture and prototype design; no private TORos source, reproducible demo or production validation is included. Forward Deployed Engineer is a target role, not a previously held title.

Key evidence: https://www.linkedin.com/pulse/part-one-orchestration-alignment-through-agentic-consensus-lh2tf/

Shipped product: https://apps.apple.com/us/app/showflex/id6757890910
Company engineering attribution: https://showflex.pro/#about
Professional identity: https://robin.ac/
Focused public guide: https://robinwinters.github.io/review/applied-ai.html
Public professional contact: robin@showflex.pro

## Source and reuse

Files and referenced article images are unchanged copies from the exact public Git revisions listed in MANIFEST.json. Original publication dates, credits and scope statements remain in the source documents. Later evidence supplements historical notes; an earlier statement that a check had not run describes that earlier checkpoint. MIT notices for the educational code remain included. No broader license is granted to other writing, artwork or private application code. No binaries, secrets, customer records, private code, mailing history or advertising financial data are included. Code and build scripts are inert files in this download; no script is executed by creating or reading this pack. The ZIP is a portable review artifact, not a claim of ATS parsing or search indexing.
