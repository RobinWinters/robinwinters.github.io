# Robin Winters - Fitness technology: public work-sample pack

Dated October 4, 2026. This is a self-authored selection of existing public work and professional evidence, assembled with editorial and coding-assistant support. It is not an independent assessment, a new credential or an employment application.

## Review path

1. Read role-resume.txt or the editable role-resume.docx.
2. Read professional-record.json for supported facts and unresolved details.
3. Review the included project accounts and focused review-guide.md.
4. Follow original evidence URLs and use MANIFEST.json to verify the included source snapshots.

ShowFlex is a shipped iPhone fitness product. The included fitness-event-data-pipeline package is a separate educational Swift package using synthetic fixtures, not private ShowFlex ingestion code or a live event dataset. Its 0.1.1 release records twelve unique tests and four CLI cases across three toolchains; repeated toolchain execution is not additional unique test coverage. Swift Package Index acceptance remains pending. NASM-CPT and NASM Certified Nutritionist are user-confirmed; individual verification dates are unresolved. PBC issuer verification is linked in the record. No clinical, efficacy, accuracy or Apple endorsement claim is made.

Key evidence: https://github.com/RobinWinters/fitness-event-data-pipeline/releases/tag/0.1.1

Shipped product: https://apps.apple.com/us/app/showflex/id6757890910
Company engineering attribution: https://showflex.pro/#about
Professional identity: https://robin.ac/
Focused public guide: https://robinwinters.github.io/review/fitness-tech.html
Public professional contact: robin@showflex.pro

## Source and reuse

Files and referenced article images are unchanged copies from the exact public Git revisions listed in MANIFEST.json. Original publication dates, credits and scope statements remain in the source documents. Later evidence supplements historical notes; an earlier statement that a check had not run describes that earlier checkpoint. MIT notices for the educational code remain included. No broader license is granted to other writing, artwork or private application code. No binaries, secrets, customer records, private code, mailing history or advertising financial data are included. Code and build scripts are inert files in this download; no script is executed by creating or reading this pack. The ZIP is a portable review artifact, not a claim of ATS parsing or search indexing.
